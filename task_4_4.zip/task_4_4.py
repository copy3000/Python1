
import utils

print(utils.currency_rates('EUR'))